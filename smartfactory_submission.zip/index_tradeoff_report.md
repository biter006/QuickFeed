# Báo cáo đánh đổi Index SmartFactory

`idx_fat_covering(sensor_id, recorded_at, temperature, humidity, status)` giúp Dashboard đọc toàn bộ dữ liệu cần hiển thị ngay từ secondary index. Đây là Covering Index, nên trong `EXPLAIN` có thể xuất hiện `Using index`. Tuy nhiên, SmartFactory nhận dữ liệu liên tục từ hàng nghìn cảm biến. Mỗi lần INSERT, InnoDB phải ghi khóa mới và duy trì cây B-Tree cho tất cả cột của index. Các cột `temperature`, `humidity` và `status` làm mỗi entry lớn hơn, tăng Data Page, RAM Buffer Pool, Disk và chi phí ghi.

Giải pháp là xóa Fat Index và tạo `idx_lean_search(sensor_id, recorded_at)`. Hai cột này khớp điều kiện lọc của Dashboard: một cảm biến cụ thể và khoảng thời gian. MySQL vẫn xác định đúng vùng bản ghi bằng index, vì vậy `EXPLAIN` phải hiển thị `key = idx_lean_search` với `type` là `ref` hoặc `range`. Truy vấn cần đọc thêm bảng gốc để lấy nhiệt độ, độ ẩm và trạng thái, nên mất lợi ích Covering Index; đây là đánh đổi có chủ đích.

Sau khi chạy script, ghi số liệu thực tế từ `information_schema.TABLES`:

| Chỉ số | Trước | Sau |
| --- | ---: | ---: |
| Data size MB | ... | ... |
| Index size MB | ... | ... |

Với hệ thống ghi thời gian thực, giảm `Index_length` và Write Penalty quan trọng hơn lợi ích SELECT cực nhỏ của Fat Index.
