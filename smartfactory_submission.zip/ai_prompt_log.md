# Nhật ký trao đổi AI về Clustered và Secondary Index

## Covering Index

**Prompt:** Covering Index là gì và vì sao truy vấn SELECT có thể nhanh hơn khi tất cả cột cần đọc nằm trong index?

**Kết quả áp dụng:** Covering Index chứa cả cột lọc lẫn cột SELECT. MySQL có thể trả dữ liệu từ index mà không cần tra lại bảng gốc, thường thể hiện bằng `Using index` trong EXPLAIN.

## Write Penalty

**Prompt:** Vì sao thêm nhiều cột vào một secondary B-Tree index làm INSERT chậm hơn?

**Kết quả áp dụng:** Mỗi INSERT phải thêm entry vào secondary index. Entry rộng hơn làm tăng I/O, dùng nhiều Buffer Pool và có thể gây page split; update các cột được index cũng phải cập nhật cây index.

## Lean Index

**Prompt:** Với `WHERE sensor_id = ? AND recorded_at >= ?`, index `(sensor_id, recorded_at)` có phù hợp không?

**Kết quả áp dụng:** Có. Điều kiện bằng trên `sensor_id` là tiền tố index, sau đó `recorded_at` dùng range. Cấu trúc này giúp tìm đúng vùng thời gian mà không đưa temperature, humidity hay status vào index.
