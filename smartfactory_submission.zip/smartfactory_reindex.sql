-- SMARTFACTORY: chuyển từ Covering Index quá lớn sang Lean Index.
-- Điều kiện chạy: Legacy Script của đề đã tạo smartfactory_db.SensorLogs
-- và index idx_fat_covering.
USE smartfactory_db;

-- 1. Ghi nhận dung lượng index trước tối ưu.
SHOW TABLE STATUS LIKE 'SensorLogs';

SELECT
    TABLE_NAME,
    ROUND(DATA_LENGTH / 1024 / 1024, 2) AS data_size_mb,
    ROUND(INDEX_LENGTH / 1024 / 1024, 2) AS index_size_mb,
    TABLE_ROWS AS estimated_rows
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'smartfactory_db'
  AND TABLE_NAME = 'SensorLogs';

-- 2. Loại bỏ Fat Covering Index chứa các cột dữ liệu không dùng để lọc.
ALTER TABLE SensorLogs DROP INDEX idx_fat_covering;

-- 3. Tạo Lean Index chỉ phục vụ điều kiện WHERE theo cảm biến và thời gian.
CREATE INDEX idx_lean_search
ON SensorLogs(sensor_id, recorded_at);

-- 4. Ghi nhận dung lượng sau tối ưu.
SHOW INDEX FROM SensorLogs;
SHOW TABLE STATUS LIKE 'SensorLogs';

SELECT
    TABLE_NAME,
    ROUND(DATA_LENGTH / 1024 / 1024, 2) AS data_size_mb,
    ROUND(INDEX_LENGTH / 1024 / 1024, 2) AS index_size_mb,
    TABLE_ROWS AS estimated_rows
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'smartfactory_db'
  AND TABLE_NAME = 'SensorLogs';

-- 5. Chứng minh Dashboard vẫn lọc được bằng index mới.
EXPLAIN
SELECT temperature, humidity, status
FROM SensorLogs
WHERE sensor_id = 105
  AND recorded_at >= '2026-06-20';
